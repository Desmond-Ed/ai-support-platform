# Project 33 — Project Plan

## Governance model
Two-agent executor/reviewer setup. Executor builds; a separate reviewer
role inspects/tests/challenges independently before each phase gate
passes — the executor does not grade its own work, though in practice
this session both builds and self-verifies with real command output,
flagging anything it can't verify itself (sandbox network limits) rather
than asserting it.

Operating rules: don't skip phases or change approved architecture
without explicit approval; never claim "done/working/tested" without
showing the proof; Node owns app state, Python owns AI only; no
hard-coded secrets; RBAC enforced server-side everywhere; RAG must
escalate rather than invent facts; after each phase, run
tests/logs/migrations/API/frontend checks and produce a short report
before moving on.

## Phase list and status

| # | Phase | Status |
|---|---|---|
| 1 | Repository and dev environment | ✅ **DONE, closed** — verified live via `docker-compose up --build` on the user's actual machine |
| 2 | Database and Prisma schema | 🔶 **IN PROGRESS** — schema written and `prisma validate` confirmed passing; blocked on a known upstream Prisma 7 bug for `migrate dev`, workaround (`--url` flag) given, awaiting user's run output |
| 3 | Authentication and authorisation | Not started |
| 4 | Conversation and messaging | Not started |
| 5 | React chat interface | Not started |
| 6 | Python AI service | Not started |
| 7 | RAG and knowledge ingestion | Not started |
| 8 | Human handoff and tickets | Not started |
| 9 | Agent dashboard | Not started |
| 10 | Admin dashboard and analytics | Not started (6 charts specified in prd.md) |
| 11 | Real-time communication | Not started (notification triggers specified in prd.md) |
| 12 | Testing | Not started |
| 13 | Security and production hardening | Not started |
| 14 | Documentation and deployment | Not started |
| 15 | Stretch goals | **Blocked until Phase 14's 18-item gate passes** — do not start early |

## Phase 1 — closed, evidence summary
All 5 Docker containers (postgres, redis, backend, ai-service, frontend)
confirmed healthy on the user's machine; pgvector extension confirmed
created; all three service health checks confirmed 200 by the user
directly in-browser. Full detail in architecture.md and the repo's own
`docs/` folder.

Bugs caught and fixed during Phase 1 (pattern worth watching for going
forward — cold/fresh-environment issues that a warm dev sandbox masks):
- `mkdir -p dir/{a,b,c}` brace expansion silently no-ops under `/bin/sh`
- Unpinned `@eslint/js` resolved to an incompatible major version on a
  truly fresh `npm install` (Docker's cold build caught it)

## Phase 2 — in progress, current blocker
Schema (12 spec entities + `RefreshToken` + separate `Embedding` table,
both flagged/justified) written and passed `prisma validate` on the
user's machine. `prisma migrate dev` is hitting a confirmed open
upstream Prisma 7 bug (`datasource.url property is required` despite
correct config) — workaround given (`--url` CLI flag). Also had to
migrate the whole schema/config from originally-authored Prisma 6-style
syntax to Prisma 7's `prisma.config.ts` + driver-adapter pattern
mid-phase, since Prisma 7 (Nov 2025) postdates the assistant's training
data. See architecture.md's "Prisma 7" section for full detail — this is
the single biggest source of friction so far and should be watched for
recurrence (e.g. any new machine/CI setup will need the same
`--url` workaround until Prisma ships a fix upstream).

**Next action**: get the user's `migrate dev --url ...` output and
`Get-Content .env` output, confirm the migration actually created
tables, then run `prisma generate` → `npm run build` → `npm run db:seed`
to fully close the phase.

## Phase 10 requirements (for later reference)
Six charts: daily conversations, weekly conversations, AI resolution
rate, ticket volume, popular topics, customer satisfaction. Full detail
in prd.md.

## Phase 11 requirements (for later reference)
Notification triggers: ticket created, agent replies, ticket status
changes, AI hands off to agent, ticket resolved — wired to the existing
Socket.IO events (`ticket_updated`, `agent_assigned`, `notification`),
not a new event system.

## Phase 15 requirements (for later reference, do not start early)
AI cost monitoring + model evaluation dashboard, gated behind Phase 14's
18-item acceptance gate. Other "bonus" ideas (voice, multi-language,
PWA) are explicitly out of scope — document as future work only.

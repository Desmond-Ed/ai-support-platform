# Project 33 — Memory / Working Principles

## Standing operating rules (from the user's master prompt)
1. Follow phase order strictly; don't skip a phase or change approved
   architecture without explicit user approval — ask first.
2. Never claim "done"/"working"/"tested" without showing the actual
   test/output that proves it.
3. Node owns application state; Python owns AI processing only. Never
   blur this boundary. Document the sync-vs-queued reasoning for every
   new Node↔Python call site in `docs/ai.md` as it's built, not
   retroactively.
4. No hard-coded secrets — env vars only.
5. Enforce RBAC on every relevant endpoint once auth exists; never trust
   client-supplied roles.
6. RAG layer must not invent policies/facts absent from the knowledge
   base — state uncertainty and escalate instead of guessing.
7. After each phase: run tests, check logs, fix failures, verify
   migrations/API/frontend behavior, then produce a short implementation
   report before moving on. Don't advance if a critical test is failing.
8. When acting as reviewer/QA, don't accept the executor's claims at
   face value — inspect and run checks independently.

## How this session has actually behaved (continue this pattern)
- Sandbox limitations disclosed explicitly, never papered over: no
  Docker daemon in the build sandbox; `binaries.prisma.sh`
  network-blocked there too. Both stated plainly, pushed to the user's
  real environment for actual verification.
- When the user pasted the *real* full orchestration spec after Phase 1
  was already built from an inline summary, the correct move was to
  diff the built repo against the real spec and fix actual gaps found —
  not assume the summary was close enough.
- When something broke on the user's machine, the fix was traced to a
  real, specific root cause (unpinned dependency; brace-expansion
  shell quirk; a genuine Prisma 7 breaking change; then a genuine
  currently-open Prisma 7 upstream bug) and verified where possible,
  rather than patched blindly and re-asserted as fixed.
- **New pattern from Phase 2, worth carrying forward explicitly**: when
  something looks like it might be a knowledge-cutoff gap (a tool/
  library did something the assistant didn't expect), the right move is
  to *search first*, distinguish "I got this wrong" from "this is a
  genuinely new breaking change past my training data" from "this is a
  currently-open upstream bug other people are also hitting" — and say
  explicitly which one it is, with sources, rather than guess-and-check
  repeatedly at the user's expense. This was done for the Prisma 7
  config migration (found the real correct syntax via search) and for
  the `datasource.url` bug (found multiple GitHub issues confirming
  it's not fixable locally, found the documented `--url` workaround).
- When a user's error report has multiple independent symptoms at once
  (e.g. `tsc` not found + `tsx` not found + Prisma client not found +
  missing env var, all at once), look for one root cause that explains
  all of them (fresh extraction, `npm install` never run) before
  treating each as a separate bug to fix.
- Ask a single clarifying question when genuinely at a consequential
  fork (e.g. Prisma 6 vs 7 — a real trade-off affecting the rest of the
  project); otherwise proceed and state assumptions inline.
- Do not hand-author things that a CLI tool owns the format of (e.g.
  refused to hand-write Prisma migration SQL — that's `prisma migrate
  dev`'s job, and faking it risks corrupting migration history tracking).

## Communication style that's worked
- Concrete, evidence-first reporting: tables of gate items with
  pass/fail and the specific evidence line.
- Flag self-caught mistakes plainly rather than glossing over them.
- Keep phase-closure reports short and structured; don't over-narrate
  routine steps.
- When genuinely blocked by something outside either party's control
  (upstream bug), say so plainly, cite sources, give the documented
  workaround, and keep moving — don't spiral into apology or hedge
  excessively.

# Project 33 — Architecture

## Stack (approved, do not deviate without explicit approval)
- Frontend: React + Vite + TypeScript + Tailwind CSS
- Backend: Node.js + Express + TypeScript, Prisma ORM (**v7** — see
  Prisma 7 section below, this was a mid-project major-version fight)
- Database: PostgreSQL + pgvector
- Auth: JWT + refresh tokens (httpOnly cookies)
- Real-time: Socket.IO
- Cache/Queue: Redis + BullMQ
- AI service: Python + FastAPI, LangChain (chosen over LlamaIndex), RAG
- Testing: Vitest, pytest, Playwright
- Infra: Docker + Docker Compose, GitHub Actions
- Deploy: Vercel (frontend), Railway (backend/AI service/DB)

## Core ownership principle
**Node owns application state. Python owns AI processing.** Scoped
precisely: "application state" = users, tickets, conversations,
authentication, permissions. Node is the only writer for those. Python
gets one deliberate carve-out — it writes directly to
`KnowledgeChunk`/`Embedding`/`KnowledgeDocument.status` during
ingestion, because the spec's own ingestion workflow requires it and
those tables aren't in the protected "application state" list. Node
still originates every `KnowledgeDocument` row and the ingestion job —
Python can't create new documents on its own.

Node → Python is the only allowed call direction. Sync HTTP for anything
a user is actively waiting on (chat replies); BullMQ async jobs for
everything else (ingestion, batch eval). Every new call site gets its
sync-vs-queued/failure-mode/scaling reasoning recorded in the project's
`docs/ai.md`, phase by phase, not reconstructed at the end.

## Repository structure
```
ai-support-platform/
├── frontend/   React+Vite+TS+Tailwind v4, ESLint 9 + Prettier
│   src/{components/{auth,chat,tickets,knowledge,agent,admin,common},
│         pages,layouts,hooks,services,context,types,utils}
├── backend/    Express+TS+Prisma 7
│   src/{config,middleware,routes,controllers,services,repositories,
│         validators,sockets,queues,utils,types,generated/prisma*}
│   prisma/{schema.prisma, seed.ts}
│   prisma.config.ts   ← Prisma 7 connection config (see below)
│   tests/
├── ai-service/ Python+FastAPI
│   app/{api,core,models,rag,embeddings,retrieval,llm,prompts,evaluation}
│   tests/, requirements.txt (pip-freeze pinned), ruff.toml
├── knowledge-base/, e2e/
├── docs/{architecture.md, api.md, database.md, ai.md}
├── docker-compose.yml, docker/postgres/init.sql
├── .env.example, .gitignore, README.md
└── .github/workflows/ci.yml

  *src/generated/prisma is gitignored, produced by `prisma generate`
```

## Database (Phase 2)
12 spec entities implemented: `User`, `Role` (as enum on User, not a
table — documented tradeoff), `Conversation`, `Message`, `Ticket`,
`TicketAssignment`, `KnowledgeDocument`, `KnowledgeChunk`,
`AgentAvailability`, `Notification`, `ConversationFeedback`, `AuditLog`.
Plus two additions beyond the spec's named list (both flagged as
implementing, not changing, approved architecture):
- `RefreshToken` — needed to make JWT+refresh auth actually revocable
- `Embedding` as its own table (not inline on `KnowledgeChunk`) — allows
  re-embedding with a different model without touching chunk content;
  matches the spec's own relationship diagram which shows them separate

`Embedding.vector` is `Unsupported("vector(1536)")` (1536 =
OpenAI `text-embedding-3-small`; revisit if a different model is chosen
in Phase 6/7). Prisma Client cannot read/write this column — Python's
retrieval code will use raw SQL/psycopg with pgvector's distance
operators.

## Prisma 7 — significant mid-project complication
Prisma released a major v7 (Nov 19, 2025, after the assistant's training
cutoff) that changed CLI/client configuration substantially:
- `datasource.url` removed from `schema.prisma` → moved to
  `prisma.config.ts` at the backend root.
- `generator client` uses new `provider = "prisma-client"` (not
  `prisma-client-js`) and requires an explicit `output` path — set to
  `../src/generated/prisma` so `tsc` compiles the generated TS source as
  part of the normal build.
- `PrismaClient` can no longer be constructed bare — requires a driver
  adapter. Using `@prisma/adapter-pg` + `pg`. One shared instance lives
  in `backend/src/config/db.ts`; all future repositories should import
  `prisma` from there.
- Found and fixed a real transitive high-severity vulnerability
  (`deepmerge-ts`, pulled in by Prisma's own CLI tooling) via an
  `overrides` entry in `package.json` rather than downgrading Prisma.
- **Known currently-open upstream Prisma bug**: `prisma migrate dev`
  reports `"datasource.url property is required"` even with a correct
  `prisma.config.ts` and `.env` (confirmed via multiple open GitHub
  issues, e.g. prisma/prisma#28585, #28983 — not something fixable on
  our end). **Workaround**: pass `--url` directly on the CLI command,
  which Prisma 7.2+ documents as taking precedence over
  `prisma.config.ts`. This needs to be used for `migrate dev`/`migrate
  deploy` until upstream fixes it — flag this prominently in any
  onboarding docs/CI so a future contributor doesn't lose time
  rediscovering it.
- `migrate dev`/`db push` no longer auto-run `generate` in v7 — always
  run `prisma generate` explicitly afterward.

## Deploy targets
Frontend → Vercel. Backend, AI service, Postgres, Redis → Railway.

## Environment specifics (this user's machine)
- Windows + PowerShell + Docker Desktop. A second, unrelated Docker
  project runs concurrently — caused a Redis port collision, resolved by
  remapping the host-side port only (`6380:6379`; internal Docker
  network traffic still uses `redis:6379`, unaffected). Watch for
  similar collisions on 5432/4000/5173/8000 if that other project's
  footprint changes.
- Repo is distributed as a tarball, not a git clone — `node_modules` and
  `.env` files never ship in it (deliberately) and must be recreated
  after every fresh extraction. This has caused repeated
  "tsc/tsx not recognized" and "datasource.url required" false alarms
  that were actually just "forgot to `npm install`/recreate `.env` in
  the new extraction" — check this first before assuming a new bug.
